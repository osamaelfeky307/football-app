package com.example.footballnews;
import androidx.appcompat.app.AppCompatActivity;
import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<FootballNews>>{

    private FootballNewsAdapter mFootballAdapter;
    private TextView anyStory;
    private static final int NEWS_LOADER_ID = 1;
    private static final String Football_News_Url =
            " https://content.guardianapis.com/search?api-key=94d90a53-4027-49fd-bf43-008e0682ec4e";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView newsListView = findViewById(R.id.football_news_list);
        anyStory = findViewById(R.id.noo_news);
        newsListView.setEmptyView(anyStory);
        mFootballAdapter = new FootballNewsAdapter(this, new ArrayList<FootballNews>());
        newsListView.setAdapter(mFootballAdapter);
        newsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                FootballNews currentNews = mFootballAdapter.getItem(position);
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(currentNews.getUrl()));
                startActivity(websiteIntent);
            }
        });

        ConnectivityManager connectMngr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connectMngr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            getLoaderManager().initLoader(NEWS_LOADER_ID, null, this);
        } else {
            View loadingIndicator = findViewById(R.id.mloader);
            loadingIndicator.setVisibility(View.GONE);
            anyStory.setText(R.string.no_internet);
        }
    }

    @Override
    public Loader<List<FootballNews>> onCreateLoader(int i, Bundle bundle) {
        Uri baseUri = Uri.parse(Football_News_Url);
        Uri.Builder uriBuilder = baseUri.buildUpon();
        uriBuilder.appendQueryParameter("show-tags", "contributor");
        Log.v("my_tag", "url created is: " + uriBuilder.toString());

        // Create a new loader for the given URL
        return new FootballNewsLoader(this, uriBuilder.toString());
    }



    @Override
    public void onLoaderReset(Loader<List<FootballNews>> loader) {


    }
    @Override
    public void onLoadFinished(Loader<List<FootballNews>> loader, List<FootballNews> news) {
        View loadingIndicator = findViewById(R.id.mloader);
        loadingIndicator.setVisibility(View.GONE);

        anyStory.setText(R.string.no_story);
        mFootballAdapter.clear();
        if (news != null && !news.isEmpty()) {
            mFootballAdapter.addAll(news);
        }
    }
}