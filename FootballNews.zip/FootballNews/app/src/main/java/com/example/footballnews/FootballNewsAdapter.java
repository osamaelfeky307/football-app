package com.example.footballnews;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class FootballNewsAdapter extends ArrayAdapter<FootballNews> {

    public FootballNewsAdapter(Activity context, ArrayList<com.example.footballnews.FootballNews> news) {
        super(context, 0, news);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.football_news_list, parent, false);
        }
        FootballNews currentNews = getItem(position);

        TextView titleNameView = listView.findViewById(R.id.heading_of_news);
        titleNameView.setText((currentNews.getTheHeading()));

        TextView TimeView = listView.findViewById(R.id.time_of_news);
        TimeView.setText(currentNews.getTheTime());

        TextView dateTextView = listView.findViewById(R.id.category_of_news);
        dateTextView.setText(currentNews.getTheCategory());

        TextView authorTextView = listView.findViewById(R.id.author);
        authorTextView.setText(currentNews.getAuthor());
        return listView;

    }
}
