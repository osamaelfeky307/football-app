package com.example.footballnews;

public class FootballNews {
    private String mHeading;
    private String mTime;
    private String mAuthor;
    private String mCategory;
    private String mUrl;

    public FootballNews (String theHeading , String theTime , String theCategory , String url , String author){
        mHeading = theHeading;
        mTime = theTime;
        mAuthor = author;
        mCategory =theCategory;
        mUrl = url;

    }
    public String getTheHeading(){return mHeading;}
    public String getTheTime(){return mTime;}
    public String getAuthor(){return mAuthor;}
    public String getTheCategory(){return mCategory;}
    public String getUrl(){return mUrl;}
}
